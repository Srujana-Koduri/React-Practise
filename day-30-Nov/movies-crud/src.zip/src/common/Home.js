import { Typography } from "@mui/material";

function Home(){
    return(
        <div>
            <Typography variant="h3">Welcome to Musicality</Typography>
        </div>
    )
}

export default Home;