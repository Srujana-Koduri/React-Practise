import { Typography } from "@mui/material";

function About(){
    return(
        <div>
            <Typography variant="h3">About Musicality</Typography>
        </div>
    )
}

export default About;