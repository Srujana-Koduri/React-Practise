const moviesData = [
    {
        id: 1,
        name: "Master",
        director: "Suresh",
        actor: "Vijay"
    },
    {
        id: 2,
        name: "Sarkar",
        director: "Vijay",
        actor: "Thalapthy"
    },
    {
        id: 3,
        name: "Bigil",
        director: "Kishore",
        actor: "Vijay"
    }
]

export default moviesData;